<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Datablog;
class Blog extends Controller
{
    function Postblog(Request $request){
        
        $title = $request->input("title");
        $description = $request->input("description");
        $request->file('image'); "\n";
        $filename  =  $request->file('image')->store("public/images/blog");
        $authoremail = session()->get('userEmail');
        $authorname = session()->get('userName');
        $result = new Datablog;
        $result->blogtitle = $title;

        if($description == ""){
            $description == "not found";
        }

        $result->blogdescription = $description;
        $result->blogimage = $filename;
        $result->authorid = $authoremail;
        $result->authorname = $authorname;
        $result->save();
        $request->Session()->flash('updateinfo', 'This is a message!'); 

        return back();

    }

    function showBlog(Request $request){

        return view('getblogs')->with("blogData", Datablog::all());
    }

    function deleteBlog($id, Request $request){

        $result = Datablog::where('blogid',$id);
        $result->delete();
        $request->Session()->flash('deleteblog', 'This is a message!'); 
        return back();

    }

    function updateBlog($id, Request $request){

        $result = Datablog::where('blogid',$id)->get();
        return view('updateblog')->with("blogData",Datablog::where('blogid',$id)->get());

    }

    function updateBlogFrom ($id, Request $request){

        $title = $request->input("title");
        $description = $request->input("description");
        $request->file('image'); "\n";
        if($request->file('image') == ""){

            Datablog::where('blogid',$id)->update(['blogtitle'=>$title, 'blogdescription'=>$description]);
            
        }
        else{

            $filename  =  $request->file('image')->store("public/images/blog");
            Datablog::where('blogid',$id)->update(['blogtitle'=>$title, 'blogdescription'=>$description, 'blogimage'=>$filename]);
        }
        $request->Session()->flash('updateblog', 'This is a message!'); 
        return back();
        
    }
}
