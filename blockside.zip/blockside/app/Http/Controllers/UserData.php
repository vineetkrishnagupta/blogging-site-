<?php

namespace App\Http\Controllers;
use App\Models\Datauser;

use Illuminate\Http\Request;

class UserData extends Controller
{
    function showUserData(){

        return view('userdata')->with("userData", Datauser::all());
    }

    function deleteUserData ($id, Request $request){

        $result = Datauser::where('email',$id);

        $result->delete();
        $request->Session()->flash('deleteuser', 'This is a message!'); 
        
        return back();

    }

    function uptadeUserData  ($id, Request $request){

        $name = $request->input("uname");
        $password = $request->input("password");
        $role = $request->input("role");

        Datauser::where('email',$id)->update(['name'=>$name, 'password'=>$password, 'role'=>$role]);

        $request->Session()->flash('updateuser', 'This is a message!'); 
        return back();


    }
}
