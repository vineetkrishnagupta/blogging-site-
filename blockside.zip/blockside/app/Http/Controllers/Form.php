<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Form extends Controller
{
    function login(Request $request){
        
        $email = $request->input("loginEmail");
        $password = $request->input("loginPassword");

        if(DB::table('user')->where('email',"$email")->where('password',"$password")->exists()){

            $result = DB::table('user')->where('email',"$email")->where('password',"$password")->get();
            print_r($result);

            foreach($result as $row){

                $request->session()->put('userEmail', $row->email);
                $request->session()->put('userPassword', $row->password);
                $request->session()->put('userName', $row->name);
                $request->session()->put('userRole', $row->role);
                $request->session()->put('userStatus', $row->status);
                $request->session()->put('userProfileimage', $row->profileimage);
                return redirect('');

            }

        }
        else{
            return redirect('login');
        }        

        return $request;
    }
    function logout(){
        
        session()->forget('userEmail');
        session()->forget('userPassword');
        session()->forget('userName');
        session()->forget('userRole');
        session()->forget('userStatus');
        session()->forget('userProfileimage');
        return redirect('login');

    }
    function signup(Request $request){
        
        $name = $request->input("signupfristname") ." ". $request->input("signuplastname");
        $email =    $request->input("signupemail");
        $password = $request->input("singuppassword");
        $role = $request->input("signupRole");
        $status = $request->input("userStatus");

        DB::table('user')->insert(array('name'=>$name, 'email'=>$email, 'password'=>$password, 'role'=>$role, 'status'=>$status, 'profileimage'=>""));

        $request->session()->put('userEmail', $email);
        $request->session()->put('userPassword', $password);
        $request->session()->put('userName', $name);
        $request->session()->put('userRole', $role);
        $request->session()->put('userStatus', $status);
        $request->session()->put('userProfileimage', "");
        
        return redirect('');

    }
}
