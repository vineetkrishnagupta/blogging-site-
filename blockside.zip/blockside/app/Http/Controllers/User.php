<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class User extends Controller
{
    function userInfo($urlNmae){
        if(!session()->has('userEmail')){
            if(!session()->has('userName')){
                return view('login');
            }
            return view('login');
        }
        return view('userinfo');
    }

    function profileImage(Request $request){

        if(!session()->has('userEmail')){
            if(!session()->has('userName')){
                return view('login');
            }
            return view('login');
        }
         
        $request->file('uploadimg'); 
        $filename  =  $request->file('uploadimg')->store("public/images/user");
      
        $email = session()->get('userEmail');
        $password = session()->get('userPassword');
        $result = DB::table('user')->where('email',"$email")->where('password',"$password")->update(array('profileimage'=> $filename));
        

        $request->Session()->flash('updatephoto', 'This is a message!'); 
        $request->session()->put('userProfileimage', $filename);

        return back();
    }
    function profileInfo(Request $request){

        if(!session()->has('userEmail')){
            if(!session()->has('userName')){
                return view('login');
            }
            return view('login');
        }

        $email = session()->get('userEmail');
        $password = session()->get('userPassword');

        $nname = $request->input("userName");
        $npassword = $request->input("userPassword");
        $nrole = $request->input("userRole");
        $nstatus = $request->input("userStatus");

        $result = DB::table('user')->where('email',"$email")->where('password',"$password")->update(array('name'=>$nname, 'password'=>$npassword, 'role'=>$nrole, 'status'=>$nstatus));

        $request->Session()->flash('updatephoto', 'This is a message!'); 

        $result = DB::table('user')->where('email',"$email")->where('password',"$npassword")->get();

        foreach($result as $row){
            
            $request->session()->put('userEmail', $row->email);
            $request->session()->put('userPassword', $row->password);
            $request->session()->put('userName', $row->name);
            $request->session()->put('userRole', $row->role);
            $request->session()->put('userStatus', $row->status);
            $request->session()->put('userProfileimage', $row->profileimage);

            $request->Session()->flash('updateinfo', 'This is a message!'); 
            
            return back();

        }

        return back();

    }
}
