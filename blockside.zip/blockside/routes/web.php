<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    if(!session()->has('userEmail')){
        if(!session()->has('userName')){
            return view('login');
        }
        return view('login');
    }
    return view('welcome');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/signup', function () {
    return view('signup');
});

Route::get('/newblog', function () {
    return view('newblog');
});

Route::get('/user/{id}', 'App\Http\Controllers\User@userInfo');
Route::post('user/update/profileimage', 'App\Http\Controllers\User@profileImage');
Route::post('user/update/profileinfo', 'App\Http\Controllers\User@profileInfo');
Route::get('userdata', 'App\Http\Controllers\UserData@showUserData');

Route::get('/logout', 'App\Http\Controllers\Form@logout');
Route::post('/loginform', 'App\Http\Controllers\Form@login');
Route::post('/signupform', 'App\Http\Controllers\Form@signup');

Route::get('getblogs', 'App\Http\Controllers\Blog@showBlog');
Route::post('postblog', 'App\Http\Controllers\Blog@Postblog');
Route::get('/deleteblogs/{id}', 'App\Http\Controllers\Blog@deleteBlog');
Route::get('/updateblogs/{id}', 'App\Http\Controllers\Blog@updateBlog');
Route::post('updateblogfrom/{id}', 'App\Http\Controllers\Blog@updateBlogFrom');

Route::get('userdata/delete/{id}', 'App\Http\Controllers\UserData@deleteUserData');
Route::post('userdata/update/{id}', 'App\Http\Controllers\UserData@uptadeUserData');
 
Route::view('aboutus', 'about');