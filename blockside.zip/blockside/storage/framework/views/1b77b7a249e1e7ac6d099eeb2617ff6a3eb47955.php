<!-- <?php $__currentLoopData = $blogData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
$data->blogid
$data->blogtitle
$data->blogdescription
$data->blogimage
$data->authorid
$data->authorname
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->

<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <!-- Bootstrap CSS -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
            crossorigin="anonymous"
        />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

        <title>Blogs</title>
    </head>
    <body>
    <div>
        <?php
            function clean($string) {
                $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
             
                return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
             }

             $url = clean(session()->get('userName'));
      
        ?>
      
        
        <?php $name = session()->get('userName'); ?>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand " href="/"><i class="bi bi-house-fill"></i><b> Home</b></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item">
                            <a class="nav-link active text-success" aria-current="page" href="/getblogs"><b>Blogs
                                </b></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/newblog"><b>Post
                                </b></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/aboutus"><b>About
                                </b></a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/userdata"><b>Users
                                </b></a>
                        </li>
                         
                        <li class="nav-item">
                            <a class="nav-link text-primary" href=<?php echo e("user/". $url); ?>><i
                                    class="bi bi-person-fill"></i><b><?php echo e(strtoupper($url[0].$url[1])); ?></b></button></a>
                        </li>
                    </ul>
                    <div>
                        <form class="d-flex">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                            <button class="btn btn-outline-success me-2" type="submit">
                                Search
                            </button>
                            <a href="logout" class="btn btn-outline-info"><b>logout</b></a>
                        </form>
                    </div>
                </div>
            </div>
        </nav>
    </div><br>
    <?php  if(session()->has('deleteblog')) echo '<div class="container-fluid">

<div class="alert alert-success alert-dismissible fade show" role="alert">
    
    <strong>Successfully Delete blog</strong>                    
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

</div>';?>
    <br><br>
    <div class="container"><h1><b>Blogs for you</b></h1></div><br><hr><br>
        
        <div class="container">
            <div class="row">
            <?php $__currentLoopData = $blogData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-12 col-xl-6 my-6 mb-3" style="height: auto">
                    <div class="card" style="width: 30rem">
                        <img src="<?php echo e(asset('https://source.unsplash.com/1000x400/?book'. $data->blogimage)); ?>" class="card-img-top" alt="..." />
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($data->blogtitle); ?></h5>
                            <p class="card-text">
                            <?php echo e($data->blogdescription); ?>

                            </p>
                            
                            
                            <!-- <a href=<?php echo e("deleteblogs/". $data->blogid); ?>><button class="btn btn-danger"><b>Delete</b></button></a>
                            <a href=<?php echo e("updateblogs/". $data->blogid); ?>><button class="btn btn-success"><b>Update</b></button></a><br><br><hr> -->
                            <?php if($data->authorid == session()->get('userEmail')){echo "<a href=deleteblogs/".$data->blogid."><button class="."'btn btn-danger'"."><b>Delete</b></button></a>";} else{echo'<a href="#"><button class="btn btn-danger" disabled><b>Not Deleted</b></button></a>';}?>
                            <?php if($data->authorid == session()->get('userEmail')){echo "<a href=updateblogs/".$data->blogid."><button class="."'btn btn-success'"."><b>Update</b></button></a>";}else{echo'<a href="#"><button class="btn btn-success" disabled><b>Not Updated</b></button></a>';}?><br>
                            

                            <pre>create by <b><?php echo e($data->authorname); ?></b></pre>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
            </div>
        </div>
      

        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
<?php /**PATH C:\Users\Vineet\phplaravelproject\blockside\resources\views/getblogs.blade.php ENDPATH**/ ?>