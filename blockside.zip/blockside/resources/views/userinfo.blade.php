<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css">
    <title>{{session()->get('userName');}}</title>
</head>
<body>
    <!-- <h1>Hello, world!</h1>
    <img src={{ "asset('file:///C:/Users/Vineet/Downloads/download.jfif')" }} alt="">
    <img src={{ "asset('MpXQKpDiMa6AdjuwHbqsT6GDg1mFvjSltggHpztC.jpg')" }} alt="">
    <img src="MpXQKpDiMa6AdjuwHbqsT6GDg1mFvjSltggHpztC.jpg" alt=""> -->


    <div>
        <?php
            function clean($string) {
                $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
             
                return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
             }

             $url = clean(session()->get('userName'));
              
        ?>
      
        
        <?php $name = session()->get('userName'); ?>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="/"><i class="bi bi-house-fill"></i><b> Home</b></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/getblogs"><b>Blogs
                                </b></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/newblog"><b>Post
                                </b></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/aboutus"><b>About
                                </b></a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/userdata"><b>Users
                                </b></a>
                        </li>
                         
                        <li class="nav-item">
                            <a class="nav-link text-primary" href={{"../user/". $url}}><i
                                    class="bi bi-person-fill"></i><b>{{strtoupper($url[0].$url[1]);}}</b></button></a>
                        </li>
                    </ul>
                    <div>
                        <form class="d-flex">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                            <button class="btn btn-outline-success me-2" type="submit">
                                Search
                            </button>
                            <a href="../logout" class="btn btn-outline-info"><b>logout</b></a>
                        </form>
                    </div>
                </div>
            </div>
        </nav>
    </div><br>

 

<?php  if(session()->has('updateinfo')) echo '<div class="container-fluid">

<div class="alert alert-success alert-dismissible fade show" role="alert">
    
    <strong>Sussessfull Updated</strong>                    
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

</div>';?>

    <div class="container">

        <div class="row" style="margin: 1% 1% 1% 1%;">
            <center>


                <div class="col-12 col-xl-6 col-md-12 "
                    style="height:  auto; border-radius: 10px; border-bottom-right-radius: 10px; background-color: rgb(184, 184, 184);">
                    <br>


                    <div class="container">
                        <h3 align=left>User Information</h3>

                        <hr>
                        <?php $imgname = session()->get('userProfileimage');?>
                        <?php $imgname = session()->get('userProfileimage');?>
                        <?php if($imgname == "") {
                            $imgname = "http://simpleicon.com/wp-content/uploads/user1.png";
                            echo "<img src= ".$imgname;
                        }
                        ?>

                        <img src= "{{ asset('storage/'. "$imgname")}}"
                            style=" margin-bottom: 0px;padding: 5px; border-radius: 50%; border: 3px solid black; width: 30%;"
                            alt="not found">

                        <div style="margin-top: 0px;">
                            <form action="update/profileimage" method="post" enctype=multipart/form-data>
                                {{@csrf_field()}}
                                <input type="file" name="uploadimg" id="img" required >
                                <label class="btn" for="img"></label>
                                <button type="submit" class="btn" style="margin-top: 0px;"> <b>Edit</b></button>
                            </form>
                        </div>
                        <div class="container">
                            

                        </div>
                        <h5 class="text-dark"> <b>{{session()->get('userName');}}</b> </h5>
                        <hr>
                        
                        <form action="update/profileinfo" autocomplete="off" method="post" class="row g-3" align=left>
                            {{@csrf_field()}}
                            <label for="fName" class="form-label "><i class="fa fa-user" style="font-size:18px;"></i>
                                Name</label>
                            <div class="col-md-7" style="margin-top: 0px;">

                                <input type="text" class="form-control form-control-lg" id="userName" name="userName"
                                    value="{{session()->get('userName');}}">
                            </div>

                            <div class="col-md-5" style="margin-top: 0px;">

                                <input type="text" class="form-control form-control-lg" id="lname" value='' >
                            </div>

                            <div class="col-md-12">
                                <label for="Email" class="form-label "><i class="fa fa-envelope"
                                        style="font-size:18px;"></i> Email</label>
                                <input type="email" class="form-control form-control-lg" id="Email"
                                    value="{{session()->get('userEmail');}}" readonly>
                            </div>

                            <div class="col-md-12">
                                <label for="Password" class="form-label"><i class='fas fa-key'
                                        style='font-size:18px'></i> Password</label>
                                <input type="password" class="form-control form-control-lg" id="Password" name="userPassword"
                                    value="{{session()->get('userPassword');}}">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input success" id="exampleCheck"
                                        onclick="Show()">
                                    <label class="form-check-label" for="exampleCheck">Show Password</label>
                                </div>
                            </div>
                            <div class="col-md-12" style="margin-top: 0px;">
                                <label for="Phone" class="form-label"><i class="fa fa-phone"
                                        style="font-size:18px;"></i> Role</label>
                                <input type="text" class="form-control form-control-lg" id="Phone" name="userRole"
                                    value="{{session()->get('userRole');}}">
                            </div>
                            <label for="Role" class="form-label"><i class="fa fa-comments" style="font-size:18px;"></i>
                                Status</label>
                            <div class="form-floating">
                                <textarea class="form-control" name="userStatus" style="height: 150px;"
                                    id="floatingTextarea" value="{{session()->get('userStatus');}}">{{session()->get('userStatus');}}</textarea>
                            </div>
                             <hr>
                            <button  type="submit"  style="width:100%;" class="btn btn-success btn-lg"
                                    data-bs-dismiss="modal">Submit</button><hr>
                            <a href="/" style="width:100%;">
                                <button type="button" style="width:100%;" class="btn btn-secondary btn-lg"
                                    data-bs-dismiss="modal">Back</button>
                            </a>
                            <hr>
                            <br>

                        </form>
                    </div>
                </div>
            </center>
        </div>

    </div>
    <?php  if(session()->has('updatephoto')) echo "<p class='alert alert-info'></p>";?>
    {{session('updatephoto');}}
    @if(Session::has('message'))
    <p class="alert alert-info">{{ Session::get('message') }}</p>
    @endif
    <img src="{{ asset('g7TwnpEB1x4ChvE01Ul2dJIIml16y0cVN2dJyRMM.jpg')}} " alt="">
    <img src="{{ asset('storage/'. 'public/images/user/e41eAxy2aK9TysBeOXiTUq7nImRl0hPEP83RmiS5.jpg')}} " alt="">


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script>
        function Show() {
            var mp = document.getElementById("Password");
            if (mp.type === "password") {
                mp.type = "text";
            }
            else {
                mp.type = "password";
            }
        }
    </script>

</body>

</html>