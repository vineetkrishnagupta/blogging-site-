<!-- @foreach($userData as $data)
$data->name 
$data->email 
$data->password
$data->role
$data->status

 
@endforeach -->


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>

  <div>
        <?php
            function clean($string) {
                $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
             
                return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
             }

             $url = clean(session()->get('userName'));
              
        ?>
         
        
        <?php $name = session()->get('userName'); ?>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="/"><i class="bi bi-house-fill"></i><b> Home</b></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/getblogs"><b>Blogs
                                </b></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active " aria-current="page" href="/newblog"><b>Post
                                </b></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/aboutus"><b>About
                                </b></a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link active text-success" aria-current="page" href="/userdata"><b>Users
                                </b></a>
                        </li>
                         
                        <li class="nav-item">
                            <a class="nav-link text-primary" href={{"user/". $url}}><i
                                    class="bi bi-person-fill"></i><b>{{strtoupper($url[0].$url[1]);}}</b></button></a>
                        </li>
                    </ul>
                    <div>
                        <form class="d-flex">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                            <button class="btn btn-outline-success me-2" type="submit">
                                Search
                            </button>
                            <a href="logout" class="btn btn-outline-info"><b>logout</b></a>
                        </form>
                    </div>
                </div>
            </div>
        </nav>
    </div><br>
    

  <?php  if(session()->has('deleteuser')) echo '<div class="container-fluid">

<div class="alert alert-success alert-dismissible fade show" role="alert">
    
    <strong>Successfully Delete User</strong>                    
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

</div>';?>
 <?php  if(session()->has('updateuser')) echo '<div class="container-fluid">

<div class="alert alert-success alert-dismissible fade show" role="alert">
    
    <strong>Successfully Updated User Information</strong>                    
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

</div>';?>
 
 
    <?php $no = 1;?>
    <div class="container">
    <h1><b><i class="bi bi-person-fill"></i> All User</b></h1><br>
   
    <table class="table table-striped table-hover table-bordered "  >
        <thead>
            <tr>
            <th scope="col">S no.</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Passwode</th>
            <th scope="col">Roal</th>
            <th scope="col">Operation</th>
             
            
            </tr>
        </thead>
        
        @foreach($userData as $data)
            <thead>
                <tr>
                    <form action="userdata/update/{{$data->email }}" method="post">
                    {{@csrf_field()}}
                    <th scope="row">{{$no++}}</th>
                    <th scope="row"> <input class="form-control" name="uname" value="{{$data->name }}" type="text"></th>
                    <th scope="row"> <input class="form-control" value="{{$data->email }}" type="text" readonly></th>
                    <th scope="row"> <input class="form-control" name="password" value="{{$data->password }}" type="text"></th>
                    <th scope="row"> <input class="form-control" name="role" value="{{$data->role }}" type="text"></th>
                     
                    <th scope="row">
                        <a href="userdata/delete/{{$data->email }}" class="btn btn-danger mb-1"><b>Delete</b></a>

                        <button type="submid" class="btn btn-success mb-1"><b>Update</b></button>
                    </th>
                    </form>
                   
                </tr>
            </thead>
        @endforeach
         
         
        </table>

        <hr>
             
             <a href="getblogs" class="btn btn-dark"><b>Back</b></a>
    
    </div>
   

   

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>